# ciCalibrate 0.42.2

- change `citEntry` to `bibentry` in inst/CITATION
- improve documentation of `print.supInt` and `plot.supInt`


# ciCalibrate 0.42.1

- CRAN submission
- Function `ciCalibrate` with `print` and `plot` methods for the returned
  `supInt` objects
